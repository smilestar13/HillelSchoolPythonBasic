class Group:
    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student):
        self.group.add(student)

    def delete_student(self, last_name):
        res = self.find_student(last_name)
        self.group.discard(res)

    def find_student(self, last_name):
        for st in self.group:
            if last_name in str(st):
                return st

    def __str__(self):
        all_students = ''
        for st in self.group:
            all_students += f'\n{st}'
        return f'Number:{self.number}\n {all_students}'
